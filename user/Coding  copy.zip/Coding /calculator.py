print (' Enter in two numbers a  & b  ' )
input ('numbers: a+b  ')
output ('The answer is:  ')

