Python 3.6.4 (v3.6.4:d48ecebad5, Dec 18 2017, 21:07:28) 
[GCC 4.2.1 (Apple Inc. build 5666) (dot 3)] on darwin
Type "copyright", "credits" or "license()" for more information.
>>> WARNING: The version of Tcl/Tk (8.5.9) in use may be unstable.
Visit http://www.python.org/download/mac/tcltk/ for current information.
print ('hello world')
hello world
>>> print ('hello, World! My name is Grace')
hello, World! My name is Grace
>>> print ('Hell, [user name}! My name is Grace
	   
SyntaxError: EOL while scanning string literal
>>> person = input ('Enter your name:    ')
	   
Enter your name:    
>>> print ('Hello', person, '!')
	   
Hello  !
>>> 
	   
>>> 
