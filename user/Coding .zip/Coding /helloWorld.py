print ('hello world')



